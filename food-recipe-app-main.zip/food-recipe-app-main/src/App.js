import React from 'react';
import './Components/style.css';
import Meal from './Components/Meal';
function App() {
  return(
      <Meal/>
  )
  
}

export default App;